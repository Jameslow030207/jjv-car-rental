<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-sclae-1.0">
    <title>JJV Car Rental | Payment page</title>
    
<!--Bootstrap -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css">
<!--Custome Style -->
<link rel="stylesheet" href="assets/css/style.css" type="text/css">

<!--FontAwesome Font Style -->
<link href="assets/css/font-awesome.min.css" rel="stylesheet">

<!-- shortcut icons -->
<link rel="shortcut icon" href="assets/images/logos.png">

<!--Google Font -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
<style>
body{
    margin: 0;
    padding: 0;
    background-color: black;
    font-family: 'Montserrat', sans-serif;
}

i{
    padding-right: 20px;
}
.payment_form{
    padding-top:100px;
    padding-bottom: 200px;
}

form{
    width:600px;
    margin: 100px auto 0 auto;
    padding: 20px;
    box-shadow: 0 4px 8px  #4D4D4D, 0 4px 8px 0 #363636;
    color: #fff;
}

h1{
    text-align: center;
    color: white;
    padding-bottom: 10px;
}

.box1{
    width: 100%;
    padding: 10px;
    border: none;
    border-radius: 15px;
    box-sizing: border-box;
    margin: 10px 0 15px 0;
    background-color: #ABABAB;
}

.div1{
    display: inline-block;
}

.box2{
    padding: 10px;
    border: none;
    border-radius: 15px;
    margin: 10px 0 15px 0;
    background-color: #ABABAB;
}

.btn{
    width: 45%;
    margin: 10px;
    padding: 10px;
    border: none;
    border-radius: 15px;
    background-color: #fa2837;
    font-size: 18px;
    color: #fff;
    font-weight: bold;
}
</style>
</head>
<body>
<div class="payment_form">
    <form action="action">
        <h1><i class="fa fa-credit-card-alt" aria-hidden="true"></i>Payment</h1>
        <label for="name">Customer Name</label><br>
        <input class="box1" type="text" name="name" id="name" placeholder="Enter Name"><br>
        <label for="Pemail">Email</label><br>
        <input class="box1" type="email" name="email" id="email" placeholder="Enter Email"><br>
        <label for="cardnum">Card Number</label><br>
        <input class="box1" type="number" name="number" id="number" placeholder="xxxx xxxx xxxx xxxx"><br>
        
        <div class="div1">
            <label for="cardexdate">Card expiry month</label><br>
            <input class="box2" type="month" name="month" id="month" placeholder="MM"><br>
        </div>
        
        <div class="div1">
            <label for="cardCVC">Card CVC</label><br>
            <input class="box2" type="cvc" name="cvc" id="CVC" placeholder="CVC"><br>
        </div>

        <button class="btn" type="button">Pay Now</button>
        <button class="btn" type="button">Close</button>
    </form>
</div>

<!--/my-vehicles--> 
<?php include('includes/footer.php');?>

</body>
</html>

