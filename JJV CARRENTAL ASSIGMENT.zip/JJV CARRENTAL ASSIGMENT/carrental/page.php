<?php
session_start();
error_reporting(0);
include('includes/config.php');
?>

</script>
<!DOCTYPE html>
<html lang="en">
<head>

<title>JJV Car Rental | About Us</title>
<!--Bootstrap -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css">
<!--Custome Style -->
<link rel="stylesheet" href="assets/css/style.css" type="text/css">
<!--OWL Carousel slider-->
<link rel="stylesheet" href="assets/css/owl.carousel.css" type="text/css">
<link rel="stylesheet" href="assets/css/owl.transitions.css" type="text/css">
<!--slick-slider -->
<link href="assets/css/slick.css" rel="stylesheet">
<!--bootstrap-slider -->
<link href="assets/css/bootstrap-slider.min.css" rel="stylesheet">
<!--FontAwesome Font Style -->
<link href="assets/css/font-awesome.min.css" rel="stylesheet">
<!-- shortcut icons -->
<link rel="shortcut icon" href="assets/images/logos.png">

<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">

</head>
<body>   
<!--Header-->
<?php include('includes/header.php');?>
                      <?php 
$pagetype=$_GET['type'];
$sql = "SELECT type,detail,PageName from tblpages where type=:pagetype";
$query = $dbh -> prepare($sql);
$query->bindParam(':pagetype',$pagetype,PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{ ?>
<section class="page-header aboutus_page">
  <div class="container">
    <div class="page-header_wrap">
      <div class="page-heading">
        <h1><?php   echo htmlentities($result->PageName); ?></h1>
      </div>
      <ul class="coustom-breadcrumb">
        <li><a href="#">Home</a></li>
        <li><?php   echo htmlentities($result->PageName); ?></li>
      </ul>
    </div>
  </div>
  <!-- Dark Overlay-->
  <div class="dark-overlay"></div>
</section>

<style>
*{
  margin:0;
  padding:0;
  box-sizing: border-box;
}

#icon2{
  padding-top: 9px;
  color: white;
  align-items: center;
}

#text2{
  color: white;
  font-size: 15px;
}

p .uppercase_text{
  font-size: 15px;
  font-family: 'Lato',sans-serif;
}

body{
  background: black;
}
.container-profile{
  
  width: 100%;
  align-items: center;
  justify-content: center;
  padding: 100px 6%;
}

.profile-box{
  background: #de302f;
  text-align: center;
  width: 500px;
  display: inline-block;
  margin: 0 25px 25px 25px;
  border: solid;
  border-radius: 10%;
}

.profile-pic{
  width:150px;
  height: 160px;
  margin: 25px 0 15px 0;
  border: inset;
  border-radius: 30%;
}

#icon,#text1{
  color: black;
  padding-right: 15px;
  font-size: 20px;
  font-family:Verdana (sans-serif);
}

#content-font{
  color:white;
}

#content-font p{
  color:white;
}

.page-header{
  background: url(assets/images/car-rental-banner.jpg);
  background-size: cover;
  background-position: center;
}

#back-top i{
  padding: 0;
}
</style>

<div class="container-profile">
  <div class="profile-box">
    <img src="assets/images/James.jpg" class="profile-pic">
    <h3>Manager</h3>
    <h4>LOW YONG QUAN</h4>
    <p id="text2"><i id="icon" class="fa fa-envelope-o" aria-hidden="true"></i>1211206782@student.mmu.edu.my</p>
    <P id="text2"><i id="icon" class="fa fa-whatsapp" aria-hidden="true"></i>011-21324121</P>
  </div>
  <div class="profile-box">
    <img src="assets/images/HANG.jpg" class="profile-pic">
    <h3>Sales Assistant</h3>
    <h4>NG WEI HANG</h4>
    <p id="text2"><i id="icon" class="fa fa-envelope-o" aria-hidden="true"></i>1211206782@student.mmu.edu.my</p>
    <P id="text2"> <i id="icon" class="fa fa-whatsapp" aria-hidden="true"></i>011-11233321</P>
  </div>
  <div class="profile-box">
    <img src="assets/images/Joel.jpg" class="profile-pic">
    <h3>HR</h3>
    <h4>JOEL CHIAN ZHONG YANG</h4>
    <p id="text2"><i id="icon"class="fa fa-envelope-o" aria-hidden="true"></i>1211206715@student.mmu.edu.my.com</p>
    <P id="text2"><i id="icon" class="fa fa-whatsapp" aria-hidden="true"></i>011-12355531</P>
  </div>
</div>


<section class="about_us section-padding">
  <div class="container">
    <div class="section-header">


      <h2 id="content-font"><?php   echo htmlentities($result->PageName); ?></h2>
      <p id="content-font"><?php  echo $result->detail; ?> </p>
    </div>
   <?php } }?>
  </div>
</section>


<<!--Footer -->
<?php include('includes/footer.php');?>


<!--Back to top-->
<div id="back-top" class="back-top"> <a href="#top"><i class="fa fa-angle-up" aria-hidden="true"></i> </a> </div>


<!--Login-Form -->
<?php include('includes/login.php');?>


<!--Register-Form -->
<?php include('includes/registration.php');?>


<!--Forgot-password-Form -->
<?php include('includes/forgotpassword.php');?>

<!-- Scripts --> 
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script> 
<script src="assets/js/interface.js"></script> 
<!--bootstrap-slider-JS--> 
<script src="assets/js/bootstrap-slider.min.js"></script> 
<!--Slider-JS--> 
<script src="assets/js/slick.min.js"></script> 
<script src="assets/js/owl.carousel.min.js"></script>

</body>
</html>