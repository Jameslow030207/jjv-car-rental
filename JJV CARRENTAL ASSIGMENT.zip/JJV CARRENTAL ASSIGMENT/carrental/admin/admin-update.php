<?php
session_start();
error_reporting(0);
include('includes/config.php');

if (strlen($_SESSION['alogin']) == 0) {
    header('location:index.php');
    exit();
}

// Function to add an admin
if (isset($_POST['add'])) {
    $admin_id = $_POST['admin_id'];
    $admin_name = $_POST['admin_name'];
    $password = md5($_POST['password']);

    // Perform necessary validation here
    if (empty($admin_id) || empty($admin_name) || empty($password)) {
        $error = "Please fill in all the fields.";
    } else {
        // Insert admin data into the database
        $sql = "INSERT INTO update_admin(admin_id, admin_name, password) VALUES(:admin_id, :admin_name, :password)";
        $query = $dbh->prepare($sql);
        $query->bindParam(':admin_id', $admin_id, PDO::PARAM_STR);
        $query->bindParam(':admin_name', $admin_name, PDO::PARAM_STR);
        $query->bindParam(':password', $password, PDO::PARAM_STR);
        $query->execute();

        $msg = "Admin added successfully";
    }
}

// Function to delete an admin
if (isset($_GET['delete'])) {
    $admin_id = $_GET['delete'];

    // Perform necessary deletion operation for the admin data from the database
    $sql = "DELETE FROM update_admin WHERE admin_id = :admin_id";
    $query = $dbh->prepare($sql);
    $query->bindParam(':admin_id', $admin_id, PDO::PARAM_STR);
    
    $query->execute();

    $msg = "Admin deleted successfully";
    header("Location: admin_update.php");
    exit();
}
?>

<!doctype html>
<html lang="en" class="no-js">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">

    <title>JJV Car Rental | Update Admin Details</title>

	<!-- Font awesome -->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<!-- Sandstone Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- Bootstrap Datatables -->
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<!-- Bootstrap social button library -->
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<!-- Bootstrap select -->
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<!-- Bootstrap file input -->
	<link rel="stylesheet" href="css/fileinput.min.css">
	<!-- Awesome Bootstrap checkbox -->
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<!-- Admin Stye -->
	<link rel="stylesheet" href="css/style.css">
    <style>
		.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
body {
  background-image: url('img//50834641213_90a01d6bfb_h.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}
.label-bold {
			font-weight: bold;
		}
		
		.page-title {
			font-weight: bold;
		}
		
		</style>
</head>
<body>


    <?php include('includes/header.php'); ?>
    <div class="ts-main-content">
        <?php include('includes/leftbar.php'); ?>
        <div class="content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <h2 class="page-title">Update Admins Details</h2>

                        <!-- Display success/error messages if any -->
                        <?php if (isset($msg)) { ?>
                            <div class="alert alert-success"><?php echo htmlentities($msg); ?></div>
                        <?php } else if (isset($error)) { ?>
                            <div class="alert alert-danger"><?php echo htmlentities($error); ?></div>
                        <?php } ?>

                        <div class="panel panel-default">
                            <div class="panel-heading">Add Admin</div>
                            <div class="panel-body">
                                <form method="post" class="form-horizontal">
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label">Admin ID</label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" name="admin_id" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label">Admin Name</label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" name="admin_name" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label">Password</label>
                                        <div class="col-sm-10">
                                        <input type="password" class="form-control" name="password" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-8 col-sm-offset-2">
                                            <button class="btn btn-primary" name="add" type="submit">Add Admin</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="panel panel-default">
    <div class="panel-heading">Admin List</div>
    <div class="panel-body">
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Admin ID</th>
                    <th>Admin Name</th>
                    <th>Password</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM update_admin";
                $query = $dbh->prepare($sql);
                $query->execute();
                $results = $query->fetchAll(PDO::FETCH_OBJ);
                $cnt = 1;
                if ($query->rowCount() > 0) {
                    foreach ($results as $result) {
                ?>
                <tr>
                    <td><?php echo htmlentities($cnt); ?></td>
                    <td><?php echo htmlentities($result->admin_id); ?></td>
                    <td><?php echo htmlentities($result->admin_name); ?></td>
                    <td><?php echo htmlentities($result->password); ?></td>
                    <td>
                        <a href="update-admin.php?delete=<?php echo $result->admin_id; ?>" onclick="return confirm('Are you sure you want to delete?');" class="btn btn-danger btn-xs">Delete</a>
                    </td>
                </tr>
                <?php
                        $cnt++;
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>


<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>
    </body>
</html>
